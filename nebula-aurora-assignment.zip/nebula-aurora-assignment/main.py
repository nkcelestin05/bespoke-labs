def main():
    print("Hello from nebula-aurora-assignment!")


if __name__ == "__main__":
    main()
